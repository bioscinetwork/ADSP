# AutoDock4Zn Molecular Docking Pipeline

Automated preparation scripts and workflow for performing molecular docking with **AutoDock4** and **AutoDock4Zn** on zinc-containing metalloproteins.

---

## Overview

Standard molecular docking scoring functions face difficulties with transition metals like Zinc ($\text{Zn}^{2+}$) due to non-directional electrostatics and Lennard-Jones representations. **AutoDock4Zn** introduces a force-field extension that:
1. Detects zinc coordination spheres within protein receptors (e.g. Cys, His, Asp, Glu coordination).
2. Geometrically places **tetrahedral pseudo-atoms** (`TZ`) at ideal open coordination sites.
3. Utilizes specialized non-bonded interaction parameters (`AD4Zn.dat` and `nbp_r_eps`) to accurately model coordination bonds with ligand donor atoms (oxygen, nitrogen, sulfur).

---

## Workflow Diagram

```mermaid
flowchart TD
    subgraph Receptor Preparation
        P[Protein Structure .pdb] -->|prepare_receptor4.py| R[protein.pdbqt]
        R -->|zinc_pseudo.py| RTZ[protein_tz.pdbqt\nwith TZ pseudo-atoms]
    end

    subgraph Ligand Preparation
        L[Ligand .mol2 / .pdb] -->|prepare_ligand4.py| LP[ligand.pdbqt]
    end

    subgraph Grid Generation
        RTZ & LP -->|prepare_gpf4zn.py\n+ AD4Zn.dat| GPF[protein_tz.gpf]
        GPF -->|autogrid4| MAPS[Grid Maps .glg / .map]
    end

    subgraph Molecular Docking
        RTZ & LP -->|prepare_dpf42.py| DPF[ligand_protein_tz.dpf]
        MAPS & DPF -->|autodock4| DLG[Docking Log .dlg]
    end
```

---

## Prerequisites

1. **MGLTools (v1.5.6 or v1.5.7)**
   - Required for `MolKit` and `AutoDockTools` Python 2.7 environments.
   - [Download MGLTools](https://ccsb.scripps.edu/mgltools/)
2. **AutoDock4 & AutoGrid4**
   - Standalone binaries for grid calculation (`autogrid4`) and docking calculation (`autodock4`).
   - [Download AutoDock Suite](https://autodock.scripps.edu/)

---

## Step-by-Step Command-Line Tutorial

### Step 0: Set MGLTools Environment Path

#### Windows (Command Prompt / PowerShell):
```cmd
set MGLROOT=C:\Program Files (x86)\MGLTools-1.5.7
```

#### Linux / macOS (Bash / Zsh):
```bash
export MGLROOT=/path/to/mgltools_x86_64Linux2_1.5.7
export PATH=$MGLROOT/bin:$PATH
```

---

### Step 1: Prepare the Receptor (Protein)
Converts the raw protein structure to `.pdbqt`, adds polar hydrogens, computes Gasteiger charges, and cleans water molecules.

```bash
"%MGLROOT%\python.exe" prepare_receptor4.py -r protein.pdb -o protein.pdbqt
```

---

### Step 2: Prepare the Ligand
Converts the ligand structure into `.pdbqt`, checks aromaticity, assigns charges, and sets up rotatable bonds.

```bash
"%MGLROOT%\python.exe" prepare_ligand4.py -l ligand.mol2 -o ligand.pdbqt -A hydrogens
```

---

### Step 3: Add Zinc Pseudo-Atoms (AutoDock4Zn Specific)
Identifies zinc sites and places `TZ` pseudo-atoms for tetrahedral coordination.

```bash
"%MGLROOT%\python.exe" zinc_pseudo.py -r protein.pdbqt -o protein_tz.pdbqt
```

> **Note:** If no tetrahedral zinc sites are detected, the script will notify you in the terminal.

---

### Step 4: Generate the Grid Parameter File (GPF)
Generates the `.gpf` file, links `AD4Zn.dat`, and appends zinc non-bonded potential parameters.

```bash
"%MGLROOT%\python.exe" prepare_gpf4zn.py ^
    -l ligand.pdbqt ^
    -r protein_tz.pdbqt ^
    -o protein_tz.gpf ^
    -p npts=40,40,40 ^
    -p gridcenter=x,y,z ^
    -p parameter_file=AD4Zn.dat
```
*(Replace `gridcenter=x,y,z` with the center coordinates of your target binding site).*

---

### Step 5: Run AutoGrid4
Calculates the affinity grid maps for each atom type.

```bash
autogrid4 -p protein_tz.gpf -l protein_tz.glg
```

---

### Step 6: Prepare the Docking Parameter File (DPF)
Sets up the Lamarckian Genetic Algorithm (LGA) parameters.

```bash
"%MGLROOT%\python.exe" prepare_dpf42.py ^
    -l ligand.pdbqt ^
    -r protein_tz.pdbqt ^
    -o ligand_protein_tz.dpf ^
    -p ga_num_evals=2500000 ^
    -p ga_pop_size=300 ^
    -p ga_run=100 ^
    -p rmstol=2.0
```

---

### Step 7: Run AutoDock4 (Docking Execution)
Executes the conformational search and binding energy evaluation.

```bash
autodock4 -p ligand_protein_tz.dpf -l ligand_protein_tz.dlg
```

---

## File Manifest

| File | Description |
| :--- | :--- |
| [`prepare_receptor4.py`](prepare_receptor4.py) | Converts receptor (`.pdb`/`.mol2`) to AutoDock `.pdbqt` format. |
| [`prepare_ligand4.py`](prepare_ligand4.py) | Converts ligand (`.mol2`/`.pdb`) to AutoDock `.pdbqt` format with torsion tree. |
| [`zinc_pseudo.py`](zinc_pseudo.py) | Detects zinc coordination geometry and adds `TZ` pseudo-atoms to the receptor. |
| [`prepare_gpf4zn.py`](prepare_gpf4zn.py) | Creates GPF for AutoGrid4 with AutoDock4Zn `nbp_r_eps` potentials. |
| [`prepare_gpf.py`](prepare_gpf.py) | Standard GPF generator for non-metalloprotein docking. |
| [`prepare_dpf42.py`](prepare_dpf42.py) | Generates DPF specifying search and clustering parameters for AutoDock 4.2. |
| [`AD4Zn.dat`](AD4Zn.dat) | Force-field parameter file defining zinc-specific vdW and electrostatic coefficients. |
| [`command_line_Prompt.docx`](command_line_Prompt.docx) | Original command prompt quick-reference document. |

---

## Tips & Troubleshooting

- **Python Version:** Always use the Python interpreter provided by MGLTools (`%MGLROOT%\python.exe` on Windows or `$MGLROOT/bin/pythonsh` on Unix) because these scripts depend on Python 2.7 and the `MolKit` / `AutoDockTools` packages.
- **Grid Center:** To find the optimal grid center coordinates `(x, y, z)`, load your receptor in PyMOL, ChimeraX, or AutoDockTools and inspect the coordinates of the catalytic zinc ion or bound co-crystallized ligand.

---

## References & Citations

If you use this pipeline in academic or scientific research, please cite:

1. **AutoDock4Zn Force Field:**
   - Santos-Martins, D., Forli, S., Ramos, M. J., & Olson, A. J. (2014). *AutoDock4Zn: Force Field for Small-Molecule Docking to Zinc-Metalloproteins.* **Journal of Chemical Information and Modeling**, 54(8), 2371–2379. [DOI: 10.1021/ci500209e](https://pubs.acs.org/doi/abs/10.1021/ci500209e).
2. **AutoDock4 Suite:**
   - Morris, G. M., Huey, R., Lindstrom, W., Sanner, M. F., Belew, R. K., Goodsell, D. S., & Olson, A. J. (2009). *AutoDock4 and AutoDockTools4: Automated docking with selective receptor flexibility.* **Journal of Computational Chemistry**, 30(16), 2785–2791.
3. **MGLTools / AutoDockTools:**
   - Sanner, M. F. (1999). *Python: a programming language for software integration and development.* **J Mol Graph Model**, 17(1), 57–61.

---

## License

This repository contains tools developed by The Scripps Research Institute and the AutoDock development team, distributed under the **GNU General Public License (GPL-3.0 / GPL-2.0)**. See [LICENSE](LICENSE) for details.
